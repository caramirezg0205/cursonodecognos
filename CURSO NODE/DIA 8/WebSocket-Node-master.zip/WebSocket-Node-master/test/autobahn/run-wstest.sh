#!/bin/bash

wstest -s ./fuzzingclient.json -m fuzzingclient
